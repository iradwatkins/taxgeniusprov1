# Complete Integration Guide

## Step-by-Step Installation

### Prerequisites

- Next.js 14+ or 15+ project with App Router
- React 18+
- TypeScript (recommended)
- shadcn/ui components (or replace with your UI library)

### Step 1: Get Square Credentials

1. Go to https://developer.squareup.com/apps
2. Create a new application or use existing one
3. Get your credentials:
   - **Application ID**: Found in "Credentials" tab
   - **Access Token**: Found in "Credentials" tab
   - **Location ID**: Found in "Locations" tab

### Step 2: Install Dependencies

```bash
npm install square
# or
yarn add square
# or
pnpm add square
```

### Step 3: Copy Files

Copy these files to your Next.js project:

```
📁 lib/square.ts → your-project/src/lib/square.ts
📁 components/square-card-payment.tsx → your-project/src/components/checkout/
📁 components/cashapp-qr-payment.tsx → your-project/src/components/checkout/
📁 api/checkout/process-square-payment/route.ts → your-project/src/app/api/checkout/process-square-payment/route.ts
```

### Step 4: Configure Environment Variables

Create or update your `.env.local` file:

```bash
# Backend (secret - server-side only)
SQUARE_ACCESS_TOKEN=your_access_token_here
SQUARE_LOCATION_ID=your_location_id_here
SQUARE_ENVIRONMENT=sandbox

# Frontend (public - required for Square Web SDK)
NEXT_PUBLIC_SQUARE_APPLICATION_ID=your_app_id_here
NEXT_PUBLIC_SQUARE_LOCATION_ID=your_location_id_here
NEXT_PUBLIC_SQUARE_ENVIRONMENT=sandbox
```

**Important:** Don't commit `.env.local` to git!

### Step 5: Update Dependencies (if using shadcn/ui)

The components use these UI components from shadcn/ui:
- Button
- Card
- Alert
- Input
- Label
- Checkbox

If you don't have shadcn/ui, install it:

```bash
npx shadcn-ui@latest init
npx shadcn-ui@latest add button card alert input label checkbox
```

Or replace with your own UI library.

### Step 6: Add Square SDK Script (Optional)

The components automatically load the Square SDK script. But you can add it to your layout for better performance:

```tsx
// app/layout.tsx
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <head>
        <link rel="preload" href="https://web.squarecdn.com/v1/square.js" as="script" />
      </head>
      <body>{children}</body>
    </html>
  )
}
```

### Step 7: Use in Your Checkout Page

```tsx
// app/checkout/page.tsx
'use client'

import { useState } from 'react'
import { SquareCardPayment } from '@/components/checkout/square-card-payment'
import { CashAppQRPayment } from '@/components/checkout/cashapp-qr-payment'
import { useRouter } from 'next/navigation'

export default function CheckoutPage() {
  const router = useRouter()
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cashapp'>('card')
  const [total] = useState(99.99) // Your order total

  const handlePaymentSuccess = (result: Record<string, unknown>) => {
    console.log('Payment successful!', result)

    // TODO: Save order to database
    // TODO: Send confirmation email
    // TODO: Redirect to success page

    router.push('/checkout/success?orderId=' + result.paymentId)
  }

  const handlePaymentError = (error: string) => {
    console.error('Payment failed:', error)
    alert('Payment failed: ' + error)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Checkout</h1>

      {/* Payment Method Selector */}
      <div className="flex gap-4 mb-8">
        <button
          className={`px-6 py-3 rounded-lg ${paymentMethod === 'card' ? 'bg-primary text-white' : 'bg-gray-200'}`}
          onClick={() => setPaymentMethod('card')}
        >
          Credit Card
        </button>
        <button
          className={`px-6 py-3 rounded-lg ${paymentMethod === 'cashapp' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}
          onClick={() => setPaymentMethod('cashapp')}
        >
          Cash App Pay
        </button>
      </div>

      {/* Payment Component */}
      {paymentMethod === 'card' ? (
        <SquareCardPayment
          applicationId={process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID!}
          locationId={process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID!}
          total={total}
          environment={process.env.NEXT_PUBLIC_SQUARE_ENVIRONMENT as 'sandbox' | 'production'}
          onPaymentSuccess={handlePaymentSuccess}
          onPaymentError={handlePaymentError}
          onBack={() => router.push('/cart')}
        />
      ) : (
        <CashAppQRPayment
          total={total}
          onPaymentSuccess={handlePaymentSuccess}
          onPaymentError={handlePaymentError}
          onBack={() => router.push('/cart')}
        />
      )}
    </div>
  )
}
```

## Advanced Configuration

### Add Billing Contact Pre-fill

```tsx
<SquareCardPayment
  applicationId={process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID!}
  locationId={process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID!}
  total={total}
  billingContact={{
    givenName: user.firstName,
    familyName: user.lastName,
    email: user.email,
    phone: user.phone,
    addressLines: [user.address],
    city: user.city,
    state: user.state,
    countryCode: 'US',
    postalCode: user.zipCode,
  }}
  environment="sandbox"
  onPaymentSuccess={handlePaymentSuccess}
  onPaymentError={handlePaymentError}
  onBack={() => router.back()}
/>
```

### Use Saved Payment Methods

```tsx
import { useState, useEffect } from 'react'

// Fetch saved payment methods from your database
const [savedMethod, setSavedMethod] = useState(null)

useEffect(() => {
  fetch('/api/user/payment-methods')
    .then(res => res.json())
    .then(data => setSavedMethod(data.defaultMethod))
}, [])

<SquareCardPayment
  applicationId={process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID!}
  locationId={process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID!}
  total={total}
  savedPaymentMethod={savedMethod}
  user={{ id: userId, email: userEmail }}
  environment="sandbox"
  onPaymentSuccess={handlePaymentSuccess}
  onPaymentError={handlePaymentError}
  onBack={() => router.back()}
/>
```

## Testing

### Test Cards (Sandbox Only)

**Successful Payments:**
- Visa: 4111 1111 1111 1111
- Mastercard: 5555 5555 5555 4444
- Amex: 3782 822463 10005

**Declined:**
- Card Declined: 4000 0000 0000 0002
- Insufficient Funds: 4000 0000 0000 0341
- CVV Failure: 4000 0000 0000 0127

**CVV:** Any 3 digits (4 for Amex)
**Expiry:** Any future date
**ZIP:** Any 5 digits

### Cash App Pay Testing

In sandbox mode, Cash App Pay will use Square's test flow.

## Production Deployment

### 1. Switch to Production Credentials

Update your production `.env` file:

```bash
SQUARE_ACCESS_TOKEN=your_production_token
SQUARE_LOCATION_ID=your_production_location
SQUARE_ENVIRONMENT=production

NEXT_PUBLIC_SQUARE_APPLICATION_ID=your_production_app_id
NEXT_PUBLIC_SQUARE_LOCATION_ID=your_production_location
NEXT_PUBLIC_SQUARE_ENVIRONMENT=production
```

### 2. Security Checklist

- [ ] Never commit credentials to git
- [ ] Use environment variables for all secrets
- [ ] Verify HTTPS is enabled on your domain
- [ ] Set up webhook signature verification
- [ ] Enable Square fraud detection
- [ ] Test with real cards in production

### 3. PCI Compliance

Square handles PCI compliance for card data. You don't need to:
- Store card numbers
- Handle CVV
- Implement PCI DSS requirements

But you DO need to:
- Use HTTPS
- Secure your Square access token
- Follow Square's best practices

## Troubleshooting

### Cash App Pay Not Working

**Problem:** Button doesn't appear or shows "not available"

**Solution:**
1. Check that `NEXT_PUBLIC_SQUARE_APPLICATION_ID` is set
2. Check that `NEXT_PUBLIC_SQUARE_LOCATION_ID` is set
3. Verify variables have `NEXT_PUBLIC_` prefix (required!)
4. Restart your dev server after adding env variables
5. Check browser console for Square SDK errors

### Card Payment Fails

**Problem:** "Card validation failed" error

**Solution:**
1. Check that Square SDK loaded: Open DevTools → Network tab → Look for square.js
2. Verify environment matches (sandbox vs production)
3. Check that location ID matches your Square account
4. Try a different test card

### TypeScript Errors

**Problem:** Type errors in components

**Solution:**
1. Install Square types: `npm install --save-dev @types/square`
2. Or add type declarations: `declare global { interface Window { Square?: any } }`

## API Reference

### SquareCardPayment Props

```typescript
interface SquareCardPaymentProps {
  applicationId: string                    // NEXT_PUBLIC_SQUARE_APPLICATION_ID
  locationId: string                       // NEXT_PUBLIC_SQUARE_LOCATION_ID
  total: number                            // Amount in dollars (e.g., 99.99)
  environment?: 'sandbox' | 'production'   // Default: 'sandbox'
  billingContact?: {                       // Pre-fill customer info
    givenName?: string
    familyName?: string
    email?: string
    phone?: string
    addressLines?: string[]
    city?: string
    state?: string
    countryCode?: string
    postalCode?: string
  }
  savedPaymentMethod?: {                   // For saved cards
    id: string
    squareCardId: string
    maskedNumber: string
    cardBrand: string
  } | null
  user?: {                                 // For saving new cards
    id: string
    email: string
    name?: string | null
  } | null
  onPaymentSuccess: (result: Record<string, unknown>) => void
  onPaymentError: (error: string) => void
  onBack: () => void
}
```

### CashAppQRPayment Props

```typescript
interface CashAppQRPaymentProps {
  total: number                            // Amount in dollars (e.g., 99.99)
  onPaymentSuccess: (result: Record<string, unknown>) => void
  onPaymentError: (error: string) => void
  onBack: () => void
}
```

### Payment Success Response

```typescript
{
  success: true,
  paymentId: "abc123...",
  orderId: "your-order-id",
  orderNumber: "ORD-123",
  status: "COMPLETED",
  receiptUrl: "https://squareup.com/receipt/...",
  message: "Payment processed successfully"
}
```

## Support

- **Square Developer Docs:** https://developer.squareup.com/docs
- **Square SDK Reference:** https://github.com/square/square-nodejs-sdk
- **Test your integration:** https://developer.squareup.com/console

## Credits

Extracted from production code at [GangRun Printing](https://gangrunprinting.com)
