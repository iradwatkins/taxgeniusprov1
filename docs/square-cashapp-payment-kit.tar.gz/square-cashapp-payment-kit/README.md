# Square & Cash App Pay Integration Kit

**Production-ready payment integration for Next.js applications**

Extracted from [GangRun Printing](https://gangrunprinting.com) - a fully operational e-commerce site processing real payments.

## Features

✅ **Square Credit/Debit Card Payments** - Full Web Payments SDK integration
✅ **Cash App Pay** - QR code and mobile payments
✅ **3D Secure (SCA)** - Built-in fraud protection
✅ **Saved Payment Methods** - For logged-in users
✅ **PCI Compliant** - Square handles sensitive card data
✅ **Production Tested** - Running live on gangrunprinting.com
✅ **TypeScript** - Full type safety
✅ **Error Handling** - User-friendly error messages
✅ **Sandbox Support** - Test before going live

## Quick Start

### 1. Install Dependencies

```bash
npm install square
# or
yarn add square
```

### 2. Copy Files to Your Project

```
your-nextjs-project/
├── src/
│   ├── lib/
│   │   └── square.ts                    (from lib/)
│   ├── components/
│   │   └── checkout/
│   │       ├── square-card-payment.tsx  (from components/)
│   │       └── cashapp-qr-payment.tsx   (from components/)
│   └── app/
│       └── api/
│           └── checkout/
│               └── process-square-payment/
│                   └── route.ts          (from api/)
```

### 3. Configure Environment Variables

Copy `.env.example` to `.env.local` and fill in your Square credentials:

```bash
# Backend (secret - never exposed to browser)
SQUARE_ACCESS_TOKEN=EAAAxxxxxxxxx
SQUARE_LOCATION_ID=Lxxxxxxxxx
SQUARE_ENVIRONMENT=sandbox

# Frontend (public - required for browser SDK)
NEXT_PUBLIC_SQUARE_APPLICATION_ID=sq0idp-xxxxxxxxx
NEXT_PUBLIC_SQUARE_LOCATION_ID=Lxxxxxxxxx
NEXT_PUBLIC_SQUARE_ENVIRONMENT=sandbox
```

**Where to get credentials:** https://developer.squareup.com/apps

### 4. Use in Your Checkout

```tsx
import { SquareCardPayment } from '@/components/checkout/square-card-payment'
import { CashAppQRPayment } from '@/components/checkout/cashapp-qr-payment'

export default function CheckoutPage() {
  const [paymentMethod, setPaymentMethod] = useState('card')

  return (
    <div>
      {paymentMethod === 'card' ? (
        <SquareCardPayment
          applicationId={process.env.NEXT_PUBLIC_SQUARE_APPLICATION_ID!}
          locationId={process.env.NEXT_PUBLIC_SQUARE_LOCATION_ID!}
          total={99.99}
          environment="sandbox"
          onPaymentSuccess={(result) => {
            // Handle success - redirect to thank you page
            console.log('Payment successful!', result)
          }}
          onPaymentError={(error) => {
            // Handle error - show error message
            console.error('Payment failed:', error)
          }}
          onBack={() => setPaymentMethod('cashapp')}
        />
      ) : (
        <CashAppQRPayment
          total={99.99}
          onPaymentSuccess={(result) => console.log('Success!', result)}
          onPaymentError={(error) => console.error('Error:', error)}
          onBack={() => setPaymentMethod('card')}
        />
      )}
    </div>
  )
}
```

## What's Included

### Backend (`lib/square.ts`)
- Square SDK client initialization
- Payment creation & retrieval
- Customer management
- Order creation & fulfillment
- Webhook signature verification
- Tax calculation helpers

### Frontend Components
- **SquareCardPayment** - Credit/debit card form with Square Web SDK
- **CashAppQRPayment** - Cash App Pay button integration

### API Route (`api/checkout/process-square-payment/route.ts`)
- Payment processing endpoint
- Token verification
- Error handling (card declined, insufficient funds, etc.)
- Idempotency key generation

## Environment Variables Explained

### Why Two Sets of Variables?

**Backend Variables** (without `NEXT_PUBLIC_`)
- Secret - never exposed to browser
- Used for server-side API calls
- Example: `SQUARE_ACCESS_TOKEN`

**Frontend Variables** (with `NEXT_PUBLIC_`)
- Public - visible in browser JavaScript
- Required for Square Web SDK
- Cash App Pay runs client-side and NEEDS these
- Example: `NEXT_PUBLIC_SQUARE_APPLICATION_ID`

**CRITICAL:** Cash App Pay will NOT work without `NEXT_PUBLIC_` prefixed variables!

## Testing

### Sandbox Mode
Use Square's test card numbers:
- **Success:** 4111 1111 1111 1111
- **Decline:** 4000 0000 0000 0002
- CVV: Any 3 digits
- Expiry: Any future date

### Cash App Pay Sandbox
Use Square's sandbox environment with test Cash App accounts.

## Production Checklist

- [ ] Get production credentials from Square
- [ ] Change `SQUARE_ENVIRONMENT` to `production`
- [ ] Change `NEXT_PUBLIC_SQUARE_ENVIRONMENT` to `production`
- [ ] Update webhook URL to your production domain
- [ ] Set up webhook signature verification
- [ ] Test with real (non-test) cards
- [ ] Verify PCI compliance requirements

## Support

This code is extracted from a live production site. If you encounter issues:

1. Check environment variables are set correctly
2. Verify `NEXT_PUBLIC_` prefix for frontend variables
3. Check browser console for Square SDK errors
4. Review Square API logs in your Square dashboard

## License

MIT - Free to use in your projects

## Credits

Extracted from [GangRun Printing](https://gangrunprinting.com)
Built with Next.js 15, Square SDK v43+, React 18+
