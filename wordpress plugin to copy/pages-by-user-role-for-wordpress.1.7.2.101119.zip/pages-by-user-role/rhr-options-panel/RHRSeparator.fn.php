<?php

function RHRSeparator(){
	return (object)array(
		'component' => 'div',
		'className' => 'rhop-main-area-spacer',
		'_children' => array()
	);
}