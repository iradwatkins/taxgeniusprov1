<?php

namespace FluentBookingPro\App\Core;

use FluentBookingPro\App\Core\AppTrait;

class App
{   
    use AppTrait;
}
