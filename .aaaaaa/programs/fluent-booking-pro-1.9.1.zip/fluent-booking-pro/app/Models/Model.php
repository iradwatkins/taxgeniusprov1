<?php

namespace FluentBookingPro\App\Models;

use FluentBooking\App\Models\Model as BaseModel;

class Model extends BaseModel
{
    // ...
}
