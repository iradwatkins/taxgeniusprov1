<?php

/*
 * Require any extra files here. For example::
 * require_once "shortcodes.php";
 * require_once "crontasks.php";
 */

/**
 * @var $app FluentBooking\Framework\Foundation\Application
 */

require_once FLUENT_BOOKING_PRO_DIR . 'app/Services/Integrations/integrations.php';
